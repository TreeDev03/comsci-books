package com.example.sample;

import android.content.Context;



import java.lang.reflect.Type;
import java.util.ArrayList;

public class Utils {

    private ArrayList<Book> allBooks;


    private static Utils instance;

    private ArrayList<Book> alreadyReadBooks;

    private ArrayList<Book> currentlyReadBooks;

    private ArrayList<Book> favorite;

;


            /*
Fetching the data to other activitys when set on click listener or delete is activated.

 */


    private Utils(Context context) {



        if (null == allBooks) {
            allBooks = new ArrayList<>();

            initData();
        }


        if (null == alreadyReadBooks ) {
            alreadyReadBooks = new ArrayList<>();

        }

        if (null == getCurrentlyReadBooks()) {
            currentlyReadBooks = new ArrayList<>();


        }

        if (null == getFavoriteBooks()) {
            favorite = new ArrayList<>();


        }

    }





        private void initData () {

            ArrayList<Book> books = new ArrayList<>();


            allBooks.add(new Book(1, "Introducing python", "Bill Lubanovic", 630,
                    "https://images-na.ssl-images-amazon.com/images/I/51yPhKJee5L._SX379_BO1,204,203,200_.jpg",
                    "Master Python", "Python gives you an introduction to the core of Python and it’s features." +
                    " It teaches you how to create statements,numbers, lists, and dictionaries to build projects. Go into python’s" +
                    " object oriented tools for code structure.\n", "https://www.oreilly.com/library/view/introducing-python-2nd/9781492051374/ "));

            allBooks.add(new Book(2, "Think Java", " Allen B. Downey/ Chris Mayfield", 301,
                    "https://cdn11.bigcommerce.com/s-igquupw3/images/stencil/1280x1280/products/1129751/28746520/9781492072508__79463.1616223802.jpg?c=2",
                    "Master Java", "Think Java is a hands-on introduction to Java The book\n starts with the most basic programming concepts" +
                    "like data types for  loops , arithmetic operators, strings and gradually works its way to advanced object-oriented techniques.", " https://www.oreilly.com/library/view/think-java-2nd/9781492072492/"));

            allBooks.add(new Book(3, "The C Programming Language", "Brain W.Kernighan/Dennis M Ritchie", 261,
                    "https://images-na.ssl-images-amazon.com/images/I/411ejyE8obL._SX377_BO1,204,203,200_.jpg",
                    "Master C", "Written by the developers of the C programming language.\n Reviews Types, operators, and expressions · " +
                    "Control flow · Functions and program\n structure · Pointers and arrays · Structures etc.", "https://www.oreilly.com/library/view/\nc-programming-language/9780133086249/ "));

            allBooks.add(new Book(4, "Cracking the Coding Interview", " Gayle Laakmann McDowell", 687,
                    "https://images-na.ssl-images-amazon.com/images/I/41oYsXjLvZL._SX348_BO1,204,203,200_.jpg",

                    "Pass the Interview", "Cracking the coding interview gives you 189 programming\n interview questions, ranging from" +
                    " the basics to the trickiest algorithm problems and " +
                    "a walk-through of how to derive each solution, so that you can learn how to get there yourself.", "https://www.crackingthecodinginterview.com/" ));

            allBooks.add(new Book(5, "Deep Learning", " Ian Goodfellow", 800,
                    "https://m.media-amazon.com/images/I/61qbj4KwauL._AC_SY780_.jpg",
                    "Machine Learning",
                    "An introduction to a broad range of topics in deep learning, covering mathematical and conceptual" +
                    " background,\n deep learning techniques used in industry, and research. Recommended by Elon Musk Tesla CEO ", "https://www.deeplearningbook.org/"));




        }


        public static Utils getInstance (Context context){
            if (null != instance) {
                return instance;


            } else {
                instance = new Utils(context);
                return instance;

            }
        }

                /*
Logic the add and remove the book data

 */


        public ArrayList<Book> getAllBooks () {
           return allBooks;
        }

        public ArrayList<Book> getAlreadyReadBooks () {
            return  alreadyReadBooks;

        }


        public ArrayList<Book> getCurrentlyReadBooks () {
           return currentlyReadBooks;
        }

        public ArrayList<Book> getFavoriteBooks () {
          return favorite;
        }

        public Book getBookById ( int id){
            ArrayList<Book> books = getAllBooks();
            if (null != books) {
                for (Book b : books) {
                    if (b.getId() == id) {
                        return b;
                    }

                }

            }

            return null;
        }

        public boolean addToAlreadyRead (Book book){
            return alreadyReadBooks.add(book);
        }


        public boolean addToCurrent (Book book){

           return currentlyReadBooks.add(book);
        }

        public boolean addToFavorite (Book book) {
            return favorite.add(book);
        }

        public boolean removeFromAlreadyRead (Book book){
           return  alreadyReadBooks.remove(book);
        }

        public boolean removeCurrentRead (Book book){
            return currentlyReadBooks.remove(book);
        }

        public boolean removeFavoriteBooks (Book book){
            return favorite.remove(book);
        }
}





